Installation:

ptscript is a perl script and thus requires Perl to be installed.
This should be the case on most Linux systems. If not, it's probably
included in the distribution CDs. You can run the script from any
directory you want, but if you don't want to type the whole path,
it is more convenient to copy ptscript to /usr/local/bin or whatever
directory is included in your path. Make sure the script is executable.

Usage:

Since the program  will modify your original script, it is a good idea
to make a backup copy first. The following command has to be used on the commandline:

ptscript -s script.txt
or
ptscript --script script.txt

where script.txt is the script file for PTStitcher and PTOptimizer.
This will display the image parameters like yaw, pitch, roll and so on 
in tabular form before and after the optimization. Now you can copy the 
optimized values from the scripts 'o' lines to the 'i' lines by hitting the
'a' key (apply). The script will be updated and the program ends.
If you are not satisfied with the optimized values you can reset the script
by hitting 'r'. This will set r, p, d, e, g, and t to 0. The yaw angles are 
calculated based on the imagenumber and assuming a 360 degree panorama. 
v, a, b and c are not altered.
Hitting any other key will just end the program without modifying your script.



Example:

I have included a test script of a panorama i shot with a 16 mm Zenitar fisheye.
Negatives were scanned with a slide scanner and manually cropped. The workflow
is as follows:

- open the script file script.txt with an editor of your choice
- uncommend the v-line which you want to optimze
- save the script and run the optimizer: PTOptimizer script.txt
- run the perl script:  ptscript -s script.txt
  You should see this table on your screen:

Before Optimization:
-------------------------------------------------------------------------------
Nr      y      p      r      v      a      b      c      d      e      g      t 
===============================================================================
 0 -180.0    0.0    0.0   82.8 -0.011  0.000 -0.021    0.0    0.0    0.0    0.0 
 1 -120.0    0.0    0.0     =0     =0     =0     =0    0.0    0.0     =0     =0 
 2  -60.0    0.0    0.0     =0     =0     =0     =0    0.0    0.0     =0     =0 
 3    0.0    0.0    0.0     =0     =0     =0     =0    0.0    0.0     =0     =0 
 4   60.0    0.0    0.0     =0     =0     =0     =0    0.0    0.0     =0     =0 
 5  120.0    0.0    0.0     =0     =0     =0     =0    0.0    0.0     =0     =0 
-------------------------------------------------------------------------------
After Optimization:
-------------------------------------------------------------------------------
Nr      y      p      r      v      a      b      c      d      e      g      t 
===============================================================================
 0 -180.0    0.0    0.0   82.8 -0.011  0.000 -0.021    0.0    0.0    0.0    0.0 
 1 -112.5    0.0    0.0   82.8 -0.011  0.000 -0.021    0.0    0.0    0.0    0.0 
 2  -53.8    0.0    0.0   82.8 -0.011  0.000 -0.021    0.0    0.0    0.0    0.0 
 3    5.7    0.0    0.0   82.8 -0.011  0.000 -0.021    0.0    0.0    0.0    0.0 
 4   66.4    0.0    0.0   82.8 -0.011  0.000 -0.021    0.0    0.0    0.0    0.0 
 5  122.9    0.0    0.0   82.8 -0.011  0.000 -0.021    0.0    0.0    0.0    0.0 
-------------------------------------------------------------------------------
Type 'a' to apply optimized values or 'r' to reset.

- when you apply the optimized values with 'a' the program terminates with
  the message 'Optimized values have been applied.'
- open the script file again and add more variables to optimize.
- repeat the steps until you are satisfied with the result

Using the folling sequence it should be possible to get the average control 
point distance below 1 pixel. The first image is the anchor. In the first step
optimize only all yaw angles except y0. In the second step
add all roll angles, than add pitch without roll, than pitch and roll, and so on...
v, a, b and c are calibrated values and do not need to optimized. 

y 
y r
y p
y p r
y p r d e
y p r d e g t





